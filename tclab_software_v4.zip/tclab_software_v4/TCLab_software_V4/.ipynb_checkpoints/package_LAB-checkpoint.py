import numpy as np

import matplotlib.pyplot as plt
from IPython.display import display, clear_output

#-----------------------------------


#-----------------------------------
def LL_RT(MV, Kp, TLead, TLag, Ts, PV, PVInit=0, method='EBD'):
    """
    The function "LL_RT" needs to be included in a "for or while loop".
    :param MV: input vector
    :param Kp: process gain
    :param T1: lead time constant (positive value) [s]
    :param T2: lag time constant (positive value) [s]
    :param Ts: sampling period [s]
    :param PV: output vector
    :param PVInit: (optional: default value is 0)
    :param method: discretisation method (optional: default value is 'EBD')
        EBD: Euler Backward difference
        EFD: Euler Forward difference
        TRAP: Trapezoïdal method
    The function "LL_RT" appends a value to the output vector "PV".
    The appended value is obtained from a recurrent equation that considers
    both lead and lag time constants.
    """
    if (TLag != 0):
        K = Ts/TLag
        if len(PV) == 0:     #if we are at the beginning
            PV.append(PVInit)
        else: 
            if method == 'EBD':
                PV.append(((1/(1+K))*PV[-1]) + ((K*Kp/(1+K))*(((1+(TLead/Ts))*MV[-1])-((TLead/Ts)*MV[-2]))))
            elif method == 'EFD':
                PV.append((1-K)*PV[-1] + Kp*K*((TLead/Ts) *MV[-1] + (1-TLead/Ts)*MV[-2]) )
            elif method == 'TRAP':
                PV.append(PV[-1]*((2-K)/(2+K)) + ((Kp*K)/(2+K)) * ((2*(TLead/Ts)+1)*MV[-1] - 2*(TLead/Ts)*MV[-2] + MV[-2] ))            
            else:      #default:EBD
                PV.append(((1/(1+K))*PV[-1]) + ((K*Kp/(1+K))*(((1+(TLead/Ts))*MV[-1])-((TLead/Ts)*MV[-2]))))
            
    else:
        PV.append(Kp*MV[-1])
    
    return PV  # Returning the updated PV list
